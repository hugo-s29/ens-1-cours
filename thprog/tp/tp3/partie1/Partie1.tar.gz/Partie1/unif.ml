open Expr
   
type subst = (var * t) list
           
exception Not_unifyable (*à "raise" si le problème n'a pas de solution*)

(*Renvoie true si x apparaît dans term*)
let rec appear (x : var) (term : t) : bool =
  failwith "TBD"
      
(*Effectue la substitution sigma(term) = term[new_x/x] *)
let rec replace ((x, new_x) : var * t) (term : t) : t =
  failwith "TBD"

(*Implémente l'unification de deux termes*)
let unify (pb : problem) : subst =
  failwith "TBD"
