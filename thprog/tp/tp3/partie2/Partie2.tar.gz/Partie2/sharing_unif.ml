[@@@ocaml.warning "-27"]
[@@@ocaml.warning "-39"]
open Sharing_expr

(* defined est l'ensemble des variables déjà définies *)
(* renvoit une expression où les variables sont remplacées par des pointeurs *)
let rec sharing_of_expr (defined : (var * t) list) (e : Expr.t) : t * ((var * t) list)=
  failwith "TBD"

(* suit les pointeurs ; ne peut pas rendre du (Var (Some _)) *)
let rec repr (term : t) : t =
  failwith "TBD"

exception Not_unifyable 
  
(* Implémente la nouvelle version de l'algorithme d'unification:
  * unifie les termes t1 et t2 en mettant à jour les variables
  * si nécessaire *)
let rec unify (t1 : t) (t2 : t) : unit =
  failwith "TBD"

(* Implémente le test de cyclicité *)
(* après avoir unifié, on peut récupérer une structure avec un cycle qui passe à travers
 * au moins un Op (par construction, pas possible d'avoir un cycle entre variables) *)
let cyclic (t : t) : bool =
  failwith "TBD"
