open Term
open Term_type

(* Il faudrait deja de quoi créer les variables "X1", "X2", etc *)


type unif_pbm = (ty*ty) list

let string_of_unif_pbm = 
  List.fold_left
   (fun s (a,b) -> 
     Printf.sprintf "%s = %s\n%s" (Type.string_of_ty a) (Type.string_of_ty b) s) ""

(* infer env v t prend un terme t à typer dans l'environnement env ((str*ty) List), et
   crée le problème d'unification associé en prenant $v$ comme variable associée à t *)
let rec infer env v = function
  | TVar x -> 
  | TCst _ -> [Tuvar v,Tint]
  | TAdd (t1, t2) ->
  | TFun (x, t) -> 
  | TApp (t1,t2) -> 
  | TLet (x, t1, t2) -> 
